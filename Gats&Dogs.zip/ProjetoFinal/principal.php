<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gats&Dogs</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<!-- criado por Willian Donizetti, RGM : 11241102384 -->
    <header>
    <script>
        var nome = prompt( "digite o seu nome:" );
        var sobronome = prompt ("Digite o seu sobronome");
        document.write("Olá," + nome + " " + sobronome);

    </script>

        <nav>
            <a href="#cachorros">Cachorros</a>
            <a href="#gatos">Gatos</a>
            <a href="#sobre nos :">Sobre nós</a>
            <a href="infor.php">Informações</a> 
        </nav>

        <center><img src="imagens/logo.png" alt="logo" width="250" height="225"></center>
        
    </header>

    <h1 id="bem vindo">Bem vindo</h1>
    <p><h2>Aqui você irá fazer a diferença</h2></p>
    <br>

    <p><h3>Animais que estão disponiveis para a adoção :</h3></p>

            <a href="#" id="cachorros"></a>

            <section class="imgcustom" id="grid-imgcustom">

                <h5>Cachorros</h5>
                <br>
                <div class="grid">

                    <div><figure>
                            <img class="perso" src="imagens/simba.jgp.jpg" alt="simba" width="200" height="300">
                            <figcaption>Simba</figcaption>
                            <br>
                        </figure>
                    </div>            

                    <div><figure>
                            <img class="perso" src="imagens/pandora.jgp.jpg" alt="pandora" width="200" height=" 300">
                            <figcaption>Pandora</figcaption>
                            <br>
                        </figure>
                    </div>

                    <div><figure>
                            <img class="perso" src="imagens/thor.jpg" alt="thor" width="200" height="300">
                            <figcaption>Thor</figcaption>
                            <br>
                        </figure>
                    </div>

                    <div><figure>
                            <img class="perso" src="imagens/zeus.jpg" alt="zeus" width="200" height="300">
                            <figcaption>Zeus</figcaption>
                            <br>
                        </figure>
                    </div>
                
                </div>

            </section>
            
            <a href="#" id="gatos"></a>

            <section class="imgcustom" id="grid-imgcustom">

                <h5>Gatos</h5>
                <br>
                <div class="grid">

                <div><figure>
                            <img class="perso" src="imagens/charles.jpg" alt="charles" width="200" height="300">
                            <figcaption>Charles</figcaption>
                            <br>
                        </figure>
                    </div>

                <div><figure>
                            <img class="perso" src="imagens/ravena.jgp.jpg" alt="ravena" width="200" height="300">
                            <figcaption>Ravena</figcaption>
                            <br>
                        </figure>
                    </div>

                <div><figure>
                            <img class="perso" src="imagens/sophia.jpg" alt="sophia" width="200" height="300">
                            <figcaption>Sophia</figcaption>
                            <br>
                        </figure>
                    </div>

                <div><figure>
                            <img class="perso" src="imagens/talis.jgp.jpg" alt="talis" width="200" height="300">
                            <figcaption>Talis</figcaption>
                            <br>
                        </figure>
                    </div>

                </div>

                </section>

            <h2>Sobre nós :</h2>
            <a href="#" id="sobre nos"></a>

            <footer>           
            <p>O nosso trabalho tem a ideia de ajudar os animais resgatados, e com ajuda de vaquinhas ou por meios de
            doações de rações, casinhas de caes e gatos ou até mesmo brinquedos, <br>conseguimos ajudar e dar o melhor possivel
            para os animais regastados. Por aqui, você poderá estar contribuindo e fazendo parte dessa familia <br> e poderemos juntos
            dar o melhor para todos e ser exemplos para ter mais gente em ajudar os animais. Conto com a colaboração e eterna gratidão.
            </p>
            <br>

            <p><a href="#bem vindo">Inicio</a></p>
            
        </footer>
</body>
</html> 